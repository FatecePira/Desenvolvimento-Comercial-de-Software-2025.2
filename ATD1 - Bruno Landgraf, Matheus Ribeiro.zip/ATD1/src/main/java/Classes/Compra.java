package Classes;

import java.util.List;
import java.time.LocalDate;

public class Compra {
    private List<Livro> livros;
    private LocalDate data;
    private double total;

    public Compra(List<Livro> livros) {
        this.livros = livros;
        this.data = LocalDate.now();
        this.total = livros.stream().mapToDouble(Livro::getPreco).sum();
    }

    public List<Livro> getLivros() { return livros; }
    public LocalDate getData() { return data; }
    public double getTotal() { return total; }

    @Override
    public String toString() {
        return "Compra em " + data + " | Total: R$" + total;
    }
}
