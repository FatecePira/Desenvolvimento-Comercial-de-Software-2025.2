package Classes;

import java.util.ArrayList;
import java.util.List;

public class Cliente extends Usuario {
    private List<Compra> historicoCompras;

    public Cliente(String nome, String email, String cpf) {
        super(nome, email, cpf);
        historicoCompras = new ArrayList<>();
    }

    public List<Compra> getHistoricoCompras() {
        return historicoCompras;
    }

    public void adicionarCompra(Compra compra) {
        historicoCompras.add(compra);
    }
}
