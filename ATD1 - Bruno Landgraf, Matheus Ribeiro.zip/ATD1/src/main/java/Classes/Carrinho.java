package Classes;

import java.util.ArrayList;
import java.util.List;

public class Carrinho {
    private List<Livro> livros;

    public Carrinho() {
        livros = new ArrayList<>();
    }

    public void adicionarLivro(Livro livro) {
        livros.add(livro);
    }

    public void removerLivro(Livro livro) {
        livros.remove(livro);
    }

    public double calcularTotal() {
        return livros.stream().mapToDouble(Livro::getPreco).sum();
    }

    public List<Livro> getLivros() {
        return livros;
    }

    public void limparCarrinho() {
        livros.clear();
    }
}
