package Views;

import Classes.*;
import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.util.ArrayList;
import java.util.List;

public class MainFrame extends JFrame {
    private final List<Usuario> usuarios = new ArrayList<>();
    private final List<Livro> livros = new ArrayList<>();
    private final Carrinho carrinho = new Carrinho();

    // Componentes
    private final CardLayout cardLayout = new CardLayout();
    private final JPanel mainPanel = new JPanel(cardLayout);

    public MainFrame() {
        setTitle("Sistema de Livraria");
        setSize(800, 600);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);

        // Inicializar telas
        mainPanel.add(menuPrincipalPanel(), "menu");
        mainPanel.add(cadastroUsuarioPanel(), "cadastroUsuario");
        mainPanel.add(cadastroLivroPanel(), "cadastroLivro");
        mainPanel.add(buscaLivroPanel(), "buscaLivro");
        mainPanel.add(carrinhoPanel(), "carrinho");

        add(mainPanel);
        cardLayout.show(mainPanel, "menu");
        setVisible(true);
    }

    // ===================== Menu Principal =====================
    private JPanel menuPrincipalPanel() {
        JPanel panel = new JPanel(new GridLayout(5, 1, 10, 10));
        panel.setBorder(BorderFactory.createEmptyBorder(50, 200, 50, 200));

        JButton btnCadastrarUsuario = new JButton("Cadastrar Usuário");
        JButton btnCadastrarLivro = new JButton("Cadastrar Livro");
        JButton btnBuscarLivro = new JButton("Buscar Livro");
        JButton btnCarrinho = new JButton("Carrinho");
        JButton btnSair = new JButton("Sair");

        btnCadastrarUsuario.addActionListener(e -> cardLayout.show(mainPanel, "cadastroUsuario"));
        btnCadastrarLivro.addActionListener(e -> cardLayout.show(mainPanel, "cadastroLivro"));
        btnBuscarLivro.addActionListener(e -> cardLayout.show(mainPanel, "buscaLivro"));
        btnCarrinho.addActionListener(e -> cardLayout.show(mainPanel, "carrinho"));
        btnSair.addActionListener(e -> System.exit(0));

        panel.add(btnCadastrarUsuario);
        panel.add(btnCadastrarLivro);
        panel.add(btnBuscarLivro);
        panel.add(btnCarrinho);
        panel.add(btnSair);

        return panel;
    }

    // ===================== Cadastro de Usuário =====================
    private JPanel cadastroUsuarioPanel() {
        JPanel panel = new JPanel(new GridLayout(6,2,5,5));
        panel.setBorder(BorderFactory.createEmptyBorder(50, 150, 50, 150));

        JLabel lblTipo = new JLabel("Tipo:");
        String[] tipos = {"Cliente", "Administrador"};
        JComboBox<String> cbTipo = new JComboBox<>(tipos);

        JLabel lblNome = new JLabel("Nome:");
        JTextField tfNome = new JTextField();

        JLabel lblEmail = new JLabel("Email:");
        JTextField tfEmail = new JTextField();

        JLabel lblCPF = new JLabel("CPF:");
        JTextField tfCPF = new JTextField();

        JButton btnSalvar = new JButton("Salvar");
        JButton btnVoltar = new JButton("Voltar");

        btnSalvar.addActionListener(e -> {
            String tipo = (String) cbTipo.getSelectedItem();
            String nome = tfNome.getText();
            String email = tfEmail.getText();
            String cpf = tfCPF.getText();

            if(tipo.equals("Cliente")) {
                usuarios.add(new Cliente(nome,email,cpf));
                JOptionPane.showMessageDialog(this, "Cliente cadastrado com sucesso!");
            } else {
                usuarios.add(new Administrador(nome,email,cpf));
                JOptionPane.showMessageDialog(this, "Administrador cadastrado com sucesso!");
            }

            tfNome.setText(""); tfEmail.setText(""); tfCPF.setText("");
        });

        btnVoltar.addActionListener(e -> cardLayout.show(mainPanel, "menu"));

        panel.add(lblTipo); panel.add(cbTipo);
        panel.add(lblNome); panel.add(tfNome);
        panel.add(lblEmail); panel.add(tfEmail);
        panel.add(lblCPF); panel.add(tfCPF);
        panel.add(btnSalvar); panel.add(btnVoltar);

        return panel;
    }

    // ===================== Cadastro de Livro =====================
    private JPanel cadastroLivroPanel() {
        JPanel panel = new JPanel(new GridLayout(6,2,5,5));
        panel.setBorder(BorderFactory.createEmptyBorder(50,150,50,150));

        JLabel lblTitulo = new JLabel("Título:");
        JTextField tfTitulo = new JTextField();
        JLabel lblAutor = new JLabel("Autor:");
        JTextField tfAutor = new JTextField();
        JLabel lblPreco = new JLabel("Preço:");
        JTextField tfPreco = new JTextField();
        JLabel lblCategoria = new JLabel("Categoria:");
        JTextField tfCategoria = new JTextField();
        JLabel lblQtd = new JLabel("Quantidade:");
        JTextField tfQtd = new JTextField();

        JButton btnSalvar = new JButton("Salvar");
        JButton btnVoltar = new JButton("Voltar");

        btnSalvar.addActionListener(e -> {
            String titulo = tfTitulo.getText();
            String autor = tfAutor.getText();
            double preco = Double.parseDouble(tfPreco.getText());
            String categoria = tfCategoria.getText();
            int qtd = Integer.parseInt(tfQtd.getText());

            livros.add(new Livro(titulo,autor,preco,categoria,qtd));
            JOptionPane.showMessageDialog(this,"Livro cadastrado com sucesso!");
            tfTitulo.setText(""); tfAutor.setText(""); tfPreco.setText(""); tfCategoria.setText(""); tfQtd.setText("");
        });

        btnVoltar.addActionListener(e -> cardLayout.show(mainPanel,"menu"));

        panel.add(lblTitulo); panel.add(tfTitulo);
        panel.add(lblAutor); panel.add(tfAutor);
        panel.add(lblPreco); panel.add(tfPreco);
        panel.add(lblCategoria); panel.add(tfCategoria);
        panel.add(lblQtd); panel.add(tfQtd);
        panel.add(btnSalvar); panel.add(btnVoltar);

        return panel;
    }

    // ===================== Busca de Livro =====================
    private JPanel buscaLivroPanel() {
        JPanel panel = new JPanel(new BorderLayout(5,5));
        JPanel topo = new JPanel(new FlowLayout());
        JTextField tfBusca = new JTextField(20);
        JButton btnBuscar = new JButton("Buscar");
        JButton btnVoltar = new JButton("Voltar");
        topo.add(tfBusca); topo.add(btnBuscar); topo.add(btnVoltar);

        DefaultListModel<Livro> listaModel = new DefaultListModel<>();
        JList<Livro> lista = new JList<>(listaModel);
        JButton btnAdicionarCarrinho = new JButton("Adicionar ao Carrinho");

        btnBuscar.addActionListener(e -> {
            listaModel.clear();
            String termo = tfBusca.getText().toLowerCase();
            for(Livro l : livros) {
                if(l.getTitulo().toLowerCase().contains(termo) ||
                   l.getAutor().toLowerCase().contains(termo) ||
                   l.getCategoria().toLowerCase().contains(termo)) {
                    listaModel.addElement(l);
                }
            }
        });

        btnAdicionarCarrinho.addActionListener(e -> {
            Livro selecionado = lista.getSelectedValue();
            if(selecionado != null) {
                if(selecionado.getQuantidadeEstoque() > 0) {
                    carrinho.adicionarLivro(selecionado);
                    JOptionPane.showMessageDialog(this,"Livro adicionado ao carrinho!");
                } else {
                    JOptionPane.showMessageDialog(this,"Livro sem estoque!");
                }
            }
        });

        btnVoltar.addActionListener(e -> cardLayout.show(mainPanel,"menu"));

        panel.add(topo, BorderLayout.NORTH);
        panel.add(new JScrollPane(lista), BorderLayout.CENTER);
        panel.add(btnAdicionarCarrinho, BorderLayout.SOUTH);

        return panel;
    }

    // ===================== Carrinho =====================
    private JPanel carrinhoPanel() {
        JPanel panel = new JPanel(new BorderLayout(5,5));
        DefaultListModel<Livro> listaModel = new DefaultListModel<>();
        JList<Livro> lista = new JList<>(listaModel);
        JButton btnRemover = new JButton("Remover");
        JButton btnFinalizar = new JButton("Finalizar Compra");
        JButton btnVoltar = new JButton("Voltar");

        JPanel botoes = new JPanel();
        botoes.add(btnRemover); botoes.add(btnFinalizar); botoes.add(btnVoltar);

        btnVoltar.addActionListener(e -> cardLayout.show(mainPanel,"menu"));

        btnRemover.addActionListener(e -> {
            Livro selecionado = lista.getSelectedValue();
            if(selecionado != null) {
                carrinho.removerLivro(selecionado);
                atualizarListaCarrinho(listaModel);
            }
        });

        btnFinalizar.addActionListener(e -> {
            if(carrinho.getLivros().isEmpty()) {
                JOptionPane.showMessageDialog(this,"Carrinho vazio!");
                return;
            }

            Compra compra = new Compra(new ArrayList<>(carrinho.getLivros()));
            for(Livro l : compra.getLivros()) {
                l.setQuantidadeEstoque(l.getQuantidadeEstoque() - 1);
            }
            carrinho.limparCarrinho();
            atualizarListaCarrinho(listaModel);
            JOptionPane.showMessageDialog(this,"Compra finalizada! Total: R$" + compra.getTotal());
        });

        panel.add(new JScrollPane(lista), BorderLayout.CENTER);
        panel.add(botoes, BorderLayout.SOUTH);

        // Atualizar lista ao entrar no painel
        panel.addHierarchyListener(e -> {
            if((e.getChangeFlags() & HierarchyEvent.SHOWING_CHANGED) != 0 && panel.isShowing()) {
                atualizarListaCarrinho(listaModel);
            }
        });

        return panel;
    }

    private void atualizarListaCarrinho(DefaultListModel<Livro> listaModel) {
        listaModel.clear();
        for(Livro l : carrinho.getLivros()) {
            listaModel.addElement(l);
        }
    }

    // ===================== Main =====================
    public static void main(String[] args) {
        SwingUtilities.invokeLater(MainFrame::new);
    }
}
